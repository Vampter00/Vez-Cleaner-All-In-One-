# ::If your having trouble

1\. Start Vez.exe as Administrator

2\. make sure you have newest Microsoft visual studio

3\. Re-install

4\. If Unban me now doesn't work make sure you have FullPC.bat is in the same folder as Vez.exe

 



Otherwise Vez Cleaner should work, if not ping **@Jay** in the discord.





### :: Fully made by **@Jay**





## **Possible Updates**

-Improved Unban rate

-Gui Improvements

-Possible Optimizations

-More Network Tweaks

-Possible Reg \& Lag improvements

-Not so many pop ups (Make it one TAP)

-DNS optimization (Make sure its the best of the best)



(This is **NOT** Promised)



:: Currently only **@Jay** Developing Vez.

-Vamp is taking time off Developing. There's no ETA

\-**I/@Jay** Don't really have time for Vez as of now, But I have published this as a apology for leaving you all in the dark for 5 Months



## @Jay does not take responsibility for any file loss or system issues that may occur as a result of using this program.

-Program Tested By @Jay

