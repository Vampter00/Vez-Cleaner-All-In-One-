# ::If your having trouble

1\. Start Vez.exe as Administrator

2\. make sure you have newest Microsoft visual studio

3\. Re-install

4\. If Unban me now doesn't work make sure you have FullPC.bat is in the same folder as Vez.exe

 



Otherwise Vez Cleaner should work, if not ping **@Jay** in the discord.





### :: Fully made by **@Jay**





## **Possible Updates**

-Improved Unban rate

-Gui Improvements

-Possible Optimizations

-More Network Tweaks

-Possible Reg \& Lag improvements

-Not so many pop ups (Make it one TAP)

-DNS optimization (Make sure its the best of the best)



(This is **NOT** Promised)  \*Development Will be slow\*



:: Currently only **@Jay** Developing Vez.

-Vamp is taking time off Developing. There's no ETA

\-**I/@Jay** Don't really have time for Vez as of now, But I have published this as a apology for leaving you all in the dark for 5 Months



## @Jay does not take responsibility for any file loss or system issues that may occur as a result of using this program.

-Program Tested By @Jay







* Version 1.6.0 Updates
* -Improved Vez Device
* -Improved Fully Network Reset
* -Improved Bloatware Checker
* -Improved IP Masker
* -Improved Ban Traces
* -Improved Fix Lag



    -Removed-

* Reg Clean From (FULL PC) -Reason \*System Crash\*



      -NOTE-

* Reg Clean on its own is completely safe.







* Possible 1.7.0 Updates
* -Reg Clean for Full PC
* -Improve Many more features (Bloatware, Mac, DNS)
* -Improve FULL UNBAN (support for games like \*Five M, warzone, BO6, GTA, R6, Hell Let Loose\* \& Improve Fortnite unban rate)

 

* possible 1.7.0 Removals
* -Boost FPS -Reason \*Bad optimization\*
* -USB Clean -Reason \*Could Delete File you May want\* (Making Vez Cleaner, Much more safer to use without loosing Files)





* -Version 1.6.0 UN BAN RATES \*%\*- (Might not be Accurate)
* Fortnite-60%
* R6-45%
* Apex-85%

 

* Version 1.7.0 Aims
* -Fortnite-90%
* -R6-80%
* -Apex-100%
* -Five M-90%
* -Warzone-80%
* -Bo6-80%
* -GTA-100%
* -Hell Let Loose-100%



######           -NOTE-

* ###### Full Un Ban REQUIRES a HWID Spoofer!
* Un Ban is ONLY CLEANING/Removing Ban Traces. You will need to SPOOF your HWID if you have a HWID BAN.
* You can check if Our/Vez Spoofer is updated.(AS of 1.6.0 its only HDD \*Hard disk\* spoof) \*Will not spoof all HWID\*













* ######                      -Spoofer related Chat-
* ###### \- Will Vez Spoofer Update? \*In Short-**Probably Not**\* (Not a Yes or a No)
* \- \*Reason\*- To make a Kernel based Spoofer is a BIG ask form 1 DEV that's not experienced in that field.
* \- I will be testing Code About HWID, So if I come across stuff and get motivated ill give it ago.



#####  

##### 

#####                -What To Expect From Vez-

* There Will ONLY be **Slow Updates** to products \*Main Product\* (Vez Cleaner) \*Most Used\*
* Will FN Chair Ever be back? - No (decided By Vamp/Cheat DEV)
* Will Vez Tweaks Update? - Not For a While.
* Will there be any Future Cheats? - Probably not (decided By Vamp/Cheat DEV)
* Will Vez Release New Products? - Until Vamp Comes Back to Developing Again - Probably not \*Reason - 1 DEV, Limited knowledge\*
* Will @Jay Update Vez Cleaner (All in one) - As much as I possibly can, Vez Cleaner already Has LOTS of options to pick so its now just improving them.
* Will Vez Carry On? - Without Vamp its hard, pushing out updates gets Boring, There's No Motivation to Keep Vez Alive At the Moment.









####  Version 1.7.0

  -ADDED-

-Improved Vez Device

-ADDED Device Name

-ADDED USER/PC INFO

-Improved Bloat ware checker



 -REMOVED-

-Disable Start up Apps \*Reason\* (Code Loss)

-REMOVED- Pricacy clean

\-

 



##### 

